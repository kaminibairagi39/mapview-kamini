import './App.css';
import Main from './component/main';
import 'bootstrap/dist/css/bootstrap.css';
import "./styles/index.scss";

function App() {
  return (
    <div className="App">
        <Main />
    </div>
  );
}

export default App;
